package com.talhanation.workers.entities;

import com.talhanation.recruits.entities.AbstractRecruitEntity;
import com.talhanation.recruits.pathfinding.AsyncGroundPathNavigation;
import com.talhanation.workers.WorkersMain;
import com.talhanation.workers.compat.DynamicTrees;
import com.talhanation.workers.config.WorkersServerConfig;
import com.talhanation.workers.entities.ai.navigation.WorkersGroundPathNavigation;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import com.talhanation.workers.entities.ai.LumberjackWorkGoal;
import com.talhanation.workers.entities.workarea.AbstractWorkAreaEntity;
import com.talhanation.workers.entities.workarea.LumberArea;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.*;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.SaplingBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.ForgeMod;
import net.minecraftforge.registries.ForgeRegistries;
import org.jetbrains.annotations.NotNull;

import javax.annotation.Nullable;
import java.util.List;
import java.util.function.Predicate;

public class LumberjackEntity extends AbstractWorkerEntity{
    public LumberArea currentLumberArea;
    public LumberjackEntity(EntityType<? extends AbstractWorkerEntity> entityType, Level world) {
        super(entityType, world);
    }

    @Override
    protected void registerGoals() {
        super.registerGoals();
        this.goalSelector.addGoal(0, new LumberjackWorkGoal(this));
    }

    public static AttributeSupplier.Builder setAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.3D)
                .add(ForgeMod.SWIM_SPEED.get(), 0.3D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.1D)
                .add(Attributes.ATTACK_DAMAGE, 0.5D)
                .add(Attributes.FOLLOW_RANGE, 32.0D)
                .add(ForgeMod.ENTITY_REACH.get(), 0D)
                .add(Attributes.ATTACK_SPEED);

    }

    @Nullable
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor world, DifficultyInstance difficultyInstance, MobSpawnType reason, @Nullable SpawnGroupData data, @Nullable CompoundTag nbt) {
        RandomSource randomsource = world.getRandom();
        SpawnGroupData ilivingentitydata = super.finalizeSpawn(world, difficultyInstance, reason, data, nbt);
        ((WorkersGroundPathNavigation)this.getNavigation()).setCanOpenDoors(true);
        this.populateDefaultEquipmentEnchantments(randomsource, difficultyInstance);

        this.initSpawn();

        return ilivingentitydata;
    }

    protected void defineSynchedData() {
        super.defineSynchedData();
    }

    @Override//not used
    public Predicate<ItemEntity> getAllowedItems() {
        return null;
    }

    @Override
    public void initSpawn() {
        this.setCustomName(Component.literal("Lumberman"));
        //this.setCost(WorkersServerConfig.FarmerCost.get());
        this.setCost(10);

        this.setEquipment();
        this.setDropEquipment();
        this.setRandomSpawnBonus();
        this.setPersistenceRequired();

        AbstractRecruitEntity.applySpawnValues(this);
    }

    @Override
    public List<Item> inventoryInputHelp() {
        return null;
    }

    public boolean wantsToKeep(ItemStack itemStack) {
        if (itemStack.getItem() instanceof AxeItem) {
            int items = countMatchingItems(stack -> stack.getItem() instanceof AxeItem);
            return items <= 1;
        }
        if(currentLumberArea != null && itemStack.is(currentLumberArea.getSaplingStack().getItem())) {
            int items = countMatchingStacks(stack -> stack.is(currentLumberArea.getSaplingStack().getItem()));
            return items <= 1;
        }


        return super.wantsToKeep(itemStack);
    }
    public boolean wantsToPickUp(ItemStack itemStack) {
        ResourceLocation id = ForgeRegistries.ITEMS.getKey(itemStack.getItem());
        if(id == null) return false;

        if(WorkersServerConfig.LumberjackPickup.get().contains(id.toString())) return true;

        if(itemStack.getItem() instanceof BlockItem blockItem && blockItem.getBlock() instanceof SaplingBlock) return true;
        if(itemStack.getItem() instanceof BlockItem blockItem && blockItem.getBlock().defaultBlockState().is(BlockTags.LOGS)) return true;
        if(itemStack.getItem() instanceof BlockItem blockItem && blockItem.getBlock().defaultBlockState().is(BlockTags.LEAVES)) return true;

        if(WorkersMain.isDynamicTreesInstalled && DynamicTrees.isDynamicTreesSeed(itemStack)) return true;
        return super.wantsToPickUp(itemStack);
    }

    @Override
    protected void finalizeBlockBreak(BlockPos pos) {
        if (WorkersMain.isDynamicTreesInstalled) {
            Level level = this.getCommandSenderWorld();
            BlockState state = level.getBlockState(pos);

            if(level.isClientSide()) return;

            if (DynamicTrees.isDynamicTreesBranch(state.getBlock())) {
                DynamicTrees.fellTree((ServerLevel)level, pos, this);
                this.damageMainHandItem();
                return;
            }
        }
        super.finalizeBlockBreak(pos);
    }

    @Override
    public AbstractWorkAreaEntity getCurrentWorkArea() {
        return currentLumberArea;
    }

    @Override
    public boolean hurt(@NotNull DamageSource dmg, float amt) {
        String id = dmg.getMsgId();
        if(id.contains("falling_tree")){//Compat dynamic trees
            return false;
        }

        return super.hurt(dmg, amt);
    }
}
