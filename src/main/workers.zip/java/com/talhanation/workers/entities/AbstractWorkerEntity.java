package com.talhanation.workers.entities;

import com.google.common.collect.ImmutableSet;
import com.talhanation.recruits.config.RecruitsClientConfig;
import com.talhanation.recruits.entities.AbstractChunkLoaderEntity;
import com.talhanation.workers.entities.ai.DepositItemsToStorage;
import com.talhanation.workers.entities.ai.GetNeededItemsFromStorage;
import com.talhanation.workers.entities.workarea.AbstractWorkAreaEntity;
import com.talhanation.workers.world.NeededItem;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.*;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.goal.MoveTowardsTargetGoal;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ShearsItem;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.jetbrains.annotations.NotNull;

import javax.annotation.Nullable;
import java.util.*;
import java.util.function.Predicate;


public abstract class AbstractWorkerEntity extends AbstractChunkLoaderEntity {

    public static final Set<Block> UNBREAKABLES = ImmutableSet.of(
            Blocks.BEDROCK,
            Blocks.BARRIER);

    public AbstractWorkerEntity(EntityType<? extends AbstractWorkerEntity> entityType, Level world) {
        super(entityType, world);
    }
    public List<NeededItem> neededItems = new ArrayList<>();
    public int farmedItems;
    public boolean forcedDeposit;
    public UUID lastStorage;
    @Override
    protected void registerGoals() {
        super.registerGoals();
        this.goalSelector.addGoal(0, new DepositItemsToStorage(this));
        this.goalSelector.addGoal(0, new GetNeededItemsFromStorage(this));

        this.goalSelector.removeGoal(new MoveTowardsTargetGoal(this, 0.9D, 32.0F));
    }

    public abstract AbstractWorkAreaEntity getCurrentWorkArea();

    /////////////////////////////////// TICK/////////////////////////////////////////
    /*
    protected @NotNull PathNavigation createNavigation(@NotNull Level level) {
        return new DebugSyncWorkerPathNavigation(this, level);//TODO ONLY TO TEST NODE EVALUATOR
    }

    public @NotNull PathNavigation getNavigation() {
        return this.navigation;//TODO REMOVE)
    }
    */

    public boolean isWorking(){
        return this.getFollowState() == 6;
    }
    @Override
    public void aiStep() {
        super.aiStep();
        if(this.getCommandSenderWorld().isClientSide()) return;

        this.getCommandSenderWorld().getProfiler().push("looting");
        if (this.canPickUpLoot() && this.isAlive() && !this.dead) {
            List<ItemEntity> nearbyItems = this.getCommandSenderWorld().getEntitiesOfClass(
                ItemEntity.class,
                this.getBoundingBox().inflate(5.5D, 5.5D, 5.5D)
            );

            for (ItemEntity itementity : nearbyItems) {
                if (!itementity.isRemoved() && !itementity.getItem().isEmpty() && !itementity.hasPickUpDelay() && this.wantsToPickUp(itementity.getItem())) {
                    this.pickUpItem(itementity);
                }
            }
        }

        if(tickCount % 20 == 0){
            if(this.getCurrentWorkArea() != null){
                double distance = this.getHorizontalDistanceTo(getCurrentWorkArea().position());
                if(distance >= 1000) this.getCurrentWorkArea().isBeingWorkedOn = false;
            }
        }
    }

    public boolean canAddItem(ItemStack itemToAdd) {
        boolean flag = false;
        List<ItemStack> inventorySlots = new ArrayList<>();
        for(int i = 6; i < this.inventory.getContainerSize(); i++){
            inventorySlots.add(inventory.items.get(i));
        }

        for(ItemStack itemstack : inventorySlots) {
            if (itemstack.isEmpty() || ItemStack.isSameItemSameTags(itemstack, itemToAdd) && itemstack.getCount() < itemstack.getMaxStackSize()) {
                flag = true;
                break;
            }
        }

        return flag;
    }
    public boolean wantsToKeep(ItemStack itemStack) {
        return (itemStack.isEdible() && itemStack.getFoodProperties(this).getNutrition() > 4);
    }
    @Override
    public boolean wantsToPickUp(ItemStack itemStack) {
        if(wantsToKeep(itemStack)) return true;

        List<NeededItem> neededItems = this.neededItems;

        for (NeededItem needed : neededItems) {
            if (needed.matches(itemStack)) {
                return true;
            }
        }
        return super.wantsToPickUp(itemStack);
    }

    @Override
    protected void pickUpItem(ItemEntity itemEntity) {
        ItemStack itemstack = itemEntity.getItem();
        if (this.wantsToPickUp(itemstack)) {
            if (!this.canAddItem(itemstack)) return;

            this.onItemPickup(itemEntity);
            this.take(itemEntity, itemstack.getCount());
            ItemStack itemstack1 = this.addItem(itemstack);

            this.farmedItems += itemstack.getCount() - itemstack1.getCount();
            NeededItem.applyToNeededItems(itemstack, neededItems);

            if (itemstack1.isEmpty()) {
                itemEntity.remove(RemovalReason.DISCARDED);
            } else {
                itemstack.setCount(itemstack1.getCount());
            }
        }
    }

    public ItemStack addItem(ItemStack itemStackToAdd) {
        if (itemStackToAdd.isEmpty()) {
            return ItemStack.EMPTY;
        } else {
            ItemStack itemstack = itemStackToAdd.copy();
            this.moveItemToOccupiedSlotsWithSameType(itemstack);
            if (itemstack.isEmpty()) {
                return ItemStack.EMPTY;
            } else {
                this.moveItemToEmptySlots(itemstack);
                return itemstack.isEmpty() ? ItemStack.EMPTY : itemstack;
            }
        }
    }

    private void moveItemToOccupiedSlotsWithSameType(ItemStack itemStackToMove) {
        for(int i = 6; i < this.getInventory().getContainerSize(); ++i) {
            ItemStack itemstack = this.getInventory().getItem(i);
            if (ItemStack.isSameItemSameTags(itemstack, itemStackToMove)) {
                this.moveItemsBetweenStacks(itemStackToMove, itemstack);
                if (itemStackToMove.isEmpty()) {
                    return;
                }
            }
        }
    }

    private void moveItemToEmptySlots(ItemStack itemStack) {
        for(int i = 6; i < this.getInventory().getContainerSize(); ++i) {
            ItemStack itemstack = this.getInventory().getItem(i);
            if (itemstack.isEmpty()) {
                this.getInventory().setItem(i, itemStack.copyAndClear());
                return;
            }
        }

    }

    private void moveItemsBetweenStacks(ItemStack p_19186_, ItemStack p_19187_) {
        int i = Math.min(64, p_19187_.getMaxStackSize());
        int j = Math.min(p_19186_.getCount(), i - p_19187_.getCount());
        if (j > 0) {
            p_19187_.grow(j);
            p_19186_.shrink(j);
            this.getInventory().setChanged();
        }
    }

    @Nullable
    public SpawnGroupData finalizeSpawn(@NotNull ServerLevelAccessor world, @NotNull DifficultyInstance diff, @NotNull MobSpawnType reason, @Nullable SpawnGroupData spawnData, @Nullable CompoundTag nbt) {
        return spawnData;
    }
    public void setDropEquipment()  {
        this.dropEquipment();
    }


    //////////////////////////////////// REGISTER////////////////////////////////////

    protected void defineSynchedData() {
        super.defineSynchedData();
    }

    public void addAdditionalSaveData(@NotNull CompoundTag nbt) {
        super.addAdditionalSaveData(nbt);

        nbt.putInt("farmedItems", farmedItems);
        if(lastStorage != null) nbt.putUUID("lastStorage", lastStorage);
    }

    public void readAdditionalSaveData(@NotNull CompoundTag nbt) {
        super.readAdditionalSaveData(nbt);

        this.farmedItems = nbt.getInt("farmedItems");
        if(nbt.contains("lastStorage")) this.lastStorage = nbt.getUUID("lastStorage");
    }

    @OnlyIn(Dist.CLIENT)
    public SoundEvent getHurtSound(DamageSource ds) {
        if(RecruitsClientConfig.RecruitsLookLikeVillagers.get()){
            return SoundEvents.VILLAGER_HURT;
        }
        else
            return SoundEvents.PLAYER_HURT;
    }

    @OnlyIn(Dist.CLIENT)
    protected SoundEvent getDeathSound() {
        if(RecruitsClientConfig.RecruitsLookLikeVillagers.get()){
            return SoundEvents.VILLAGER_DEATH;
        }
        else
            return SoundEvents.PLAYER_DEATH;
    }

    protected float getSoundVolume() {
        return 0.4F;
    }

    //////////////////////////////////// SET////////////////////////////////////

    public void setEquipment() {
    }

    public boolean needsToSleep() {
        return !this.getCommandSenderWorld().isDay();
    }

    public abstract Predicate<ItemEntity> getAllowedItems();

    public void initSpawn(){
        this.setEquipment();
        this.setDropEquipment();
        this.setPersistenceRequired();
        this.setCanPickUpLoot(true);
    }

    public double getDistanceToOwner(){
        return this.getOwner() != null ? this.distanceToSqr(this.getOwner()) : 1D;
    }

    public void tick() {
        super.tick();
        if(this.getCommandSenderWorld().isClientSide()) return;
    }

    public abstract List<Item> inventoryInputHelp();

    public boolean needsToGetToChest() {
        return this.needsToGetFood() || needsToDeposit() || needsToGetItems();
    }

    public boolean needsToDeposit() {
        return forcedDeposit || farmedItems > 128;
    }
    @Nullable
    public ItemStack getMatchingItem(Predicate<ItemStack> predicate) {
        for (ItemStack stack : this.getInventory().items) {
            if (!stack.isEmpty() && predicate.test(stack)) {
                return stack;
            }
        }
        return null;
    }

    public int countMatchingItems(Predicate<ItemStack> predicate) {
        int count = 0;

        for (ItemStack stack : this.getInventory().items) {
            if (!stack.isEmpty() && predicate.test(stack)) {
                count += stack.getCount();
            }
        }

        return count;
    }

    public int countMatchingStacks(Predicate<ItemStack> predicate) {
        int count = 0;

        for (ItemStack stack : this.getInventory().items) {
            if (!stack.isEmpty() && predicate.test(stack)) {
                count++;
            }
        }

        return count;
    }

    int currentTimeBreak;
    int breakingTime;
    int previousTimeBreak;

    public void mineBlock(BlockPos pos) {
        if (!this.isAlive()) return;

        Level level = this.getCommandSenderWorld();
        BlockState state = level.getBlockState(pos);
        if (state.isAir()) return;

        // Laubblöcke: mit Schere manuell abbauen und droppen
        if (state.getBlock() instanceof LeavesBlock && this.getMainHandItem().getItem() instanceof ShearsItem) {
            BlockEntity blockEntity = level.getBlockEntity(pos);
            List<ItemStack> drops = Block.getDrops(state, (ServerLevel) level, pos, blockEntity, this, this.getMainHandItem());

            for (ItemStack drop : drops) {
                Containers.dropItemStack(level, pos.getX(), pos.getY(), pos.getZ(), drop);
            }

            state.onRemove(level, pos, Blocks.AIR.defaultBlockState(), false); // z.B. für Sounds/Particles
            level.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
            level.playSound(null, pos, SoundEvents.SHEEP_SHEAR, SoundSource.BLOCKS, 1.0F, 1.0F); // optionaler Scher-Sound

            return;
        }

        // Normaler Abbau
        if (currentTimeBreak % 5 == 4) {
            level.playLocalSound(pos.getX(), pos.getY(), pos.getZ(),
                    state.getSoundType().getHitSound(), SoundSource.BLOCKS, 1F, 0.75F, false);
        }

        if (breakingTime == 0) {
            breakingTime = (int) (state.getDestroySpeed(level, pos) * 30);
        }

        float destroySpeed = this.getUseItem().getDestroySpeed(state) * 2;
        currentTimeBreak += (int) destroySpeed;

        int stage = (int) ((float) currentTimeBreak / breakingTime * 10);
        if (stage != previousTimeBreak) {
            level.destroyBlockProgress(1, pos, stage);
            previousTimeBreak = stage;
        }

        if (currentTimeBreak >= breakingTime) {
            this.finalizeBlockBreak(pos);
            currentTimeBreak = 0;
            breakingTime = 0;
            previousTimeBreak = 0;
        }

        this.swing(InteractionHand.MAIN_HAND);
    }

    protected void finalizeBlockBreak(BlockPos pos) {
        Level level = this.getCommandSenderWorld();
        level.destroyBlock(pos, true, this);
        this.damageMainHandItem();
    }

    public boolean needsToGetItems() {
        return neededItems.stream().anyMatch(neededItem -> neededItem.required);
    }

    public void addNeededItem(NeededItem neededItem) {
        if(neededItems.contains(neededItem)) return;

        neededItems.add(neededItem);
    }
    //@Override
    public void onItemStackAdded(ItemStack itemStack1){
        //super.onItemStackAdded(itemStack);
        ItemStack itemStack = itemStack1.copy();
        for(NeededItem neededItem : neededItems){
            if(neededItem.matches(itemStack)){
                NeededItem.applyToNeededItems(itemStack, neededItems);;
                break;
            }
        }
    }

    public void switchMainHandItem(Predicate<ItemStack> predicate) {
        if (!this.isAlive() || predicate == null) return;

        SimpleContainer inventory = this.getInventory();
        ItemStack mainHand = this.getMainHandItem();
        if (predicate.test(mainHand)) return;

        for (int i = 6; i < inventory.getContainerSize(); i++) {
            ItemStack stack = inventory.getItem(i);
            if (predicate.test(stack)) {

                inventory.setItem(i, mainHand);
                this.setItemInHand(InteractionHand.MAIN_HAND, stack);
                return;
            }
        }
    }

    public double getHorizontalDistanceTo(Vec3 target){
        Vec3 position = new Vec3(position().x, 0, position().z);
        Vec3 toTarget = new Vec3(target.x, 0, target.z);

        return position.distanceToSqr(toTarget);
    }

    @Override
    public void die(DamageSource dmg) {
        super.die(dmg);
        if(this.getCurrentWorkArea() != null) getCurrentWorkArea().setBeingWorkedOn(false);
    }

    public static boolean isPosBroken(BlockPos pos, Level level, boolean allowWater) {
        BlockState state = level.getBlockState(pos);
        if(state.isAir() || UNBREAKABLES.contains(state.getBlock())) return true;
        if(allowWater){
            Fluid fluidState = level.getFluidState(pos).getType();
            return fluidState == Fluids.WATER || fluidState == Fluids.FLOWING_WATER;
        }
        return false;
    }

    public boolean hasFreeInvSlot() {
        for (int i = 6; i < inventory.getContainerSize(); i++) {
            ItemStack stack = inventory.getItem(i);
            if (stack.isEmpty()) {
                return true;
            }
        }
        return false;
    }

    public boolean shouldWork() {
        return this.isOwned() && (this.getFollowState() == 0 || this.getFollowState() == 6);
    }
}
